from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class MyUserCreationForm(UserCreationForm):
    def __init__(self, *args, **kwargs):
        super(MyUserCreationForm, self).__init__(*args, **kwargs)
        for fieldname, field in self.fields.items():
            field.widget.attrs.update({'class': 'form-control custom-form'})
            field.label_classes = ('form-label-left',)

    class Meta:
        model = User
        fields = ("username", "password1", "password2")

    # Ejemplo de validación adicional para el campo de username
    def clean_username(self):
        username = self.cleaned_data.get("username")
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("El nombre de usuario ya existe. Por favor, elija otro.")
        return username
